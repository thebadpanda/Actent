import React from 'react';

export default function EquipmentList({ equipments }) {

    const equipmentElements = equipments.map(equipment =>
        <li key = {equipment}>{equipment}</li>
    )

    return (
        <ul>
            {equipmentElements}
        </ul>
    );
}
