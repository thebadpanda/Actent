import React from 'react';
import EquipmentList from './EquipmentList';

class Equipment extends React.Component {

    render() {

        return (
            <div>
                <h1>Equipment list:</h1>
                <EquipmentList equipments={this.props.equipments}/>
            </div>
        );
    }
}

export default Equipment;
